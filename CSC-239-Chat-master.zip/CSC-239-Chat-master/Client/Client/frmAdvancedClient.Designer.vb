﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAdvancedClient
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblRecipient = New System.Windows.Forms.Label()
        Me.cmdMinimize = New System.Windows.Forms.Label()
        Me.lblIPAddress = New System.Windows.Forms.Label()
        Me.cmdExit = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.txtDisplay = New System.Windows.Forms.Label()
        Me.cmdSend = New System.Windows.Forms.Label()
        Me.chkSpeech = New System.Windows.Forms.CheckBox()
        Me.chkEnter = New System.Windows.Forms.CheckBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblRecipient)
        Me.Panel1.Controls.Add(Me.cmdMinimize)
        Me.Panel1.Controls.Add(Me.lblIPAddress)
        Me.Panel1.Controls.Add(Me.cmdExit)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(552, 25)
        Me.Panel1.TabIndex = 0
        '
        'lblRecipient
        '
        Me.lblRecipient.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRecipient.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblRecipient.Location = New System.Drawing.Point(194, 0)
        Me.lblRecipient.Name = "lblRecipient"
        Me.lblRecipient.Size = New System.Drawing.Size(266, 24)
        Me.lblRecipient.TabIndex = 9
        Me.lblRecipient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmdMinimize
        '
        Me.cmdMinimize.BackColor = System.Drawing.Color.Transparent
        Me.cmdMinimize.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMinimize.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.cmdMinimize.Location = New System.Drawing.Point(487, -6)
        Me.cmdMinimize.Name = "cmdMinimize"
        Me.cmdMinimize.Size = New System.Drawing.Size(32, 31)
        Me.cmdMinimize.TabIndex = 7
        Me.cmdMinimize.Text = "_"
        Me.cmdMinimize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblIPAddress
        '
        Me.lblIPAddress.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIPAddress.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblIPAddress.Location = New System.Drawing.Point(6, 0)
        Me.lblIPAddress.Name = "lblIPAddress"
        Me.lblIPAddress.Size = New System.Drawing.Size(178, 24)
        Me.lblIPAddress.TabIndex = 8
        Me.lblIPAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.Color.Transparent
        Me.cmdExit.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.cmdExit.Location = New System.Drawing.Point(517, -3)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(36, 28)
        Me.cmdExit.TabIndex = 6
        Me.cmdExit.Text = "x"
        Me.cmdExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.PictureBox1)
        Me.Panel3.Controls.Add(Me.txtInput)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(184, 540)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(368, 82)
        Me.Panel3.TabIndex = 2
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox1.Location = New System.Drawing.Point(10, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(340, 1)
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'txtInput
        '
        Me.txtInput.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtInput.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.txtInput.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtInput.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtInput.Location = New System.Drawing.Point(7, 11)
        Me.txtInput.Margin = New System.Windows.Forms.Padding(10)
        Me.txtInput.MaxLength = 140
        Me.txtInput.Multiline = True
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(348, 52)
        Me.txtInput.TabIndex = 1
        Me.txtInput.Text = "Enter message here..."
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.BackgroundImage = Global.Client.My.Resources.Resources.MainOverlay
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel4.Controls.Add(Me.Label2)
        Me.Panel4.Controls.Add(Me.txtDisplay)
        Me.Panel4.Controls.Add(Me.cmdSend)
        Me.Panel4.Controls.Add(Me.chkSpeech)
        Me.Panel4.Controls.Add(Me.chkEnter)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(184, 25)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(368, 515)
        Me.Panel4.TabIndex = 3
        '
        'txtDisplay
        '
        Me.txtDisplay.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.txtDisplay.Location = New System.Drawing.Point(10, 14)
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(346, 433)
        Me.txtDisplay.TabIndex = 13
        '
        'cmdSend
        '
        Me.cmdSend.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cmdSend.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.cmdSend.Location = New System.Drawing.Point(257, 487)
        Me.cmdSend.Name = "cmdSend"
        Me.cmdSend.Size = New System.Drawing.Size(99, 23)
        Me.cmdSend.TabIndex = 12
        Me.cmdSend.Text = "Send to IP"
        Me.cmdSend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkSpeech
        '
        Me.chkSpeech.AutoSize = True
        Me.chkSpeech.Checked = True
        Me.chkSpeech.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSpeech.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkSpeech.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.chkSpeech.Location = New System.Drawing.Point(10, 467)
        Me.chkSpeech.Name = "chkSpeech"
        Me.chkSpeech.Size = New System.Drawing.Size(111, 19)
        Me.chkSpeech.TabIndex = 11
        Me.chkSpeech.Text = "Speech Enabled"
        Me.chkSpeech.UseVisualStyleBackColor = True
        '
        'chkEnter
        '
        Me.chkEnter.AutoSize = True
        Me.chkEnter.Checked = True
        Me.chkEnter.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnter.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkEnter.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.chkEnter.Location = New System.Drawing.Point(10, 486)
        Me.chkEnter.Name = "chkEnter"
        Me.chkEnter.Size = New System.Drawing.Size(158, 19)
        Me.chkEnter.TabIndex = 10
        Me.chkEnter.Text = "Press Enter to Send to IP"
        Me.chkEnter.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BackgroundImage = Global.Client.My.Resources.Resources.SidePanelOverlay8
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel2.Location = New System.Drawing.Point(0, 25)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(184, 597)
        Me.Panel2.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(12, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(158, 23)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Configure SMS"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label2.Location = New System.Drawing.Point(257, 462)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 23)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Send SMS"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label3.Location = New System.Drawing.Point(9, 185)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(172, 148)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "If we end up not needing this space, I'll take it out and make it like the other " &
    "form."
        '
        'frmAdvancedClient
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.BackgroundImage = Global.Client.My.Resources.Resources.BackgroundPlain
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(552, 622)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmAdvancedClient"
        Me.Opacity = 0.96R
        Me.Text = "frmAdvancedClient"
        Me.Panel1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents txtInput As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents cmdMinimize As Label
    Friend WithEvents lblIPAddress As Label
    Friend WithEvents cmdExit As Label
    Friend WithEvents chkSpeech As CheckBox
    Friend WithEvents chkEnter As CheckBox
    Friend WithEvents cmdSend As Label
    Friend WithEvents txtDisplay As Label
    Friend WithEvents lblRecipient As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
End Class
