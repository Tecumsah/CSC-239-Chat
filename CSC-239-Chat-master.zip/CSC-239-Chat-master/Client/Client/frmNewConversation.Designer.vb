﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewConversation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblTitleBar = New System.Windows.Forms.Label()
        Me.cmdMinimize = New System.Windows.Forms.Label()
        Me.cmdExit = New System.Windows.Forms.Label()
        Me.chkAdvanced = New System.Windows.Forms.CheckBox()
        Me.cmbRecipientNames = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdStartConversation = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtRecipientIP = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbProvider = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblTitleBar)
        Me.Panel1.Controls.Add(Me.cmdMinimize)
        Me.Panel1.Controls.Add(Me.cmdExit)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(321, 29)
        Me.Panel1.TabIndex = 5
        '
        'lblTitleBar
        '
        Me.lblTitleBar.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitleBar.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblTitleBar.Location = New System.Drawing.Point(7, 3)
        Me.lblTitleBar.Name = "lblTitleBar"
        Me.lblTitleBar.Size = New System.Drawing.Size(251, 24)
        Me.lblTitleBar.TabIndex = 10
        Me.lblTitleBar.Text = "New Conversation"
        Me.lblTitleBar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmdMinimize
        '
        Me.cmdMinimize.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdMinimize.BackColor = System.Drawing.Color.Transparent
        Me.cmdMinimize.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMinimize.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.cmdMinimize.Location = New System.Drawing.Point(256, -3)
        Me.cmdMinimize.Name = "cmdMinimize"
        Me.cmdMinimize.Size = New System.Drawing.Size(32, 31)
        Me.cmdMinimize.TabIndex = 9
        Me.cmdMinimize.Text = "_"
        Me.cmdMinimize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdExit
        '
        Me.cmdExit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdExit.BackColor = System.Drawing.Color.Transparent
        Me.cmdExit.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.cmdExit.Location = New System.Drawing.Point(286, 0)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(36, 28)
        Me.cmdExit.TabIndex = 8
        Me.cmdExit.Text = "x"
        Me.cmdExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkAdvanced
        '
        Me.chkAdvanced.AutoSize = True
        Me.chkAdvanced.Location = New System.Drawing.Point(10, 35)
        Me.chkAdvanced.Name = "chkAdvanced"
        Me.chkAdvanced.Size = New System.Drawing.Size(139, 22)
        Me.chkAdvanced.TabIndex = 6
        Me.chkAdvanced.Text = "Advanced Options"
        Me.chkAdvanced.UseVisualStyleBackColor = True
        '
        'cmbRecipientNames
        '
        Me.cmbRecipientNames.FormattingEnabled = True
        Me.cmbRecipientNames.Location = New System.Drawing.Point(10, 99)
        Me.cmbRecipientNames.Name = "cmbRecipientNames"
        Me.cmbRecipientNames.Size = New System.Drawing.Size(299, 26)
        Me.cmbRecipientNames.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 78)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 18)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Select Recipient:"
        '
        'cmdStartConversation
        '
        Me.cmdStartConversation.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cmdStartConversation.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.cmdStartConversation.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdStartConversation.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.cmdStartConversation.Location = New System.Drawing.Point(0, 407)
        Me.cmdStartConversation.Name = "cmdStartConversation"
        Me.cmdStartConversation.Size = New System.Drawing.Size(321, 35)
        Me.cmdStartConversation.TabIndex = 9
        Me.cmdStartConversation.Text = "Start Conversation"
        Me.cmdStartConversation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 143)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(155, 18)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "IP Address of Recipient:"
        '
        'txtRecipientIP
        '
        Me.txtRecipientIP.Location = New System.Drawing.Point(10, 165)
        Me.txtRecipientIP.Name = "txtRecipientIP"
        Me.txtRecipientIP.Size = New System.Drawing.Size(299, 26)
        Me.txtRecipientIP.TabIndex = 11
        '
        'Label3
        '
        Me.Label3.ForeColor = System.Drawing.Color.Gray
        Me.Label3.Location = New System.Drawing.Point(9, 231)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(300, 45)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "This information is only necessary if you plan to use SMS in this conversation."
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(10, 296)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(299, 26)
        Me.txtPhone.TabIndex = 13
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 275)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(184, 18)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Phone Number of Recipient:"
        '
        'cmbProvider
        '
        Me.cmbProvider.FormattingEnabled = True
        Me.cmbProvider.Location = New System.Drawing.Point(11, 357)
        Me.cmbProvider.Name = "cmbProvider"
        Me.cmbProvider.Size = New System.Drawing.Size(298, 26)
        Me.cmbProvider.TabIndex = 15
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 336)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(113, 18)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Service Provider:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.Color.Gray
        Me.PictureBox1.Location = New System.Drawing.Point(10, 214)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(299, 1)
        Me.PictureBox1.TabIndex = 17
        Me.PictureBox1.TabStop = False
        '
        'frmNewConversation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(321, 442)
        Me.Controls.Add(Me.cmdStartConversation)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cmbProvider)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtPhone)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtRecipientIP)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbRecipientNames)
        Me.Controls.Add(Me.chkAdvanced)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Gainsboro
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmNewConversation"
        Me.Text = "frmNewConversation"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents lblTitleBar As Label
    Friend WithEvents cmdMinimize As Label
    Friend WithEvents cmdExit As Label
    Friend WithEvents chkAdvanced As CheckBox
    Friend WithEvents cmbRecipientNames As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents cmdStartConversation As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtRecipientIP As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cmbProvider As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
