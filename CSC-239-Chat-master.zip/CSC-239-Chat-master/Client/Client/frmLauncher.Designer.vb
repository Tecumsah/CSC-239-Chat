﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLauncher
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkAdvanced = New System.Windows.Forms.CheckBox()
        Me.pnlTitleBar = New System.Windows.Forms.Panel()
        Me.lblTitleBar = New System.Windows.Forms.Label()
        Me.cmdMinimize = New System.Windows.Forms.Label()
        Me.cmdExit = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmbProvider = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtServerIP = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdStartConversation = New System.Windows.Forms.Label()
        Me.txtRecipientIP = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbRecipientName = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.nudServerPort = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmbEmailType = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.pnlTitleBar.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudServerPort, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'chkAdvanced
        '
        Me.chkAdvanced.AutoSize = True
        Me.chkAdvanced.Location = New System.Drawing.Point(10, 35)
        Me.chkAdvanced.Name = "chkAdvanced"
        Me.chkAdvanced.Size = New System.Drawing.Size(139, 22)
        Me.chkAdvanced.TabIndex = 3
        Me.chkAdvanced.Text = "Advanced Options"
        Me.chkAdvanced.UseVisualStyleBackColor = True
        '
        'pnlTitleBar
        '
        Me.pnlTitleBar.Controls.Add(Me.lblTitleBar)
        Me.pnlTitleBar.Controls.Add(Me.cmdMinimize)
        Me.pnlTitleBar.Controls.Add(Me.cmdExit)
        Me.pnlTitleBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTitleBar.Location = New System.Drawing.Point(0, 0)
        Me.pnlTitleBar.Name = "pnlTitleBar"
        Me.pnlTitleBar.Size = New System.Drawing.Size(659, 29)
        Me.pnlTitleBar.TabIndex = 4
        '
        'lblTitleBar
        '
        Me.lblTitleBar.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitleBar.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblTitleBar.Location = New System.Drawing.Point(7, 3)
        Me.lblTitleBar.Name = "lblTitleBar"
        Me.lblTitleBar.Size = New System.Drawing.Size(170, 24)
        Me.lblTitleBar.TabIndex = 10
        Me.lblTitleBar.Text = "Chat Program Launcher"
        Me.lblTitleBar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmdMinimize
        '
        Me.cmdMinimize.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdMinimize.BackColor = System.Drawing.Color.Transparent
        Me.cmdMinimize.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMinimize.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.cmdMinimize.Location = New System.Drawing.Point(595, -3)
        Me.cmdMinimize.Name = "cmdMinimize"
        Me.cmdMinimize.Size = New System.Drawing.Size(32, 31)
        Me.cmdMinimize.TabIndex = 9
        Me.cmdMinimize.Text = "_"
        Me.cmdMinimize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdExit
        '
        Me.cmdExit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdExit.BackColor = System.Drawing.Color.Transparent
        Me.cmdExit.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.cmdExit.Location = New System.Drawing.Point(625, 0)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(36, 28)
        Me.cmdExit.TabIndex = 8
        Me.cmdExit.Text = "x"
        Me.cmdExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.Color.Gray
        Me.PictureBox1.Location = New System.Drawing.Point(10, 207)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(640, 1)
        Me.PictureBox1.TabIndex = 27
        Me.PictureBox1.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(338, 315)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(113, 18)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "Service Provider:"
        '
        'cmbProvider
        '
        Me.cmbProvider.FormattingEnabled = True
        Me.cmbProvider.Location = New System.Drawing.Point(339, 336)
        Me.cmbProvider.Name = "cmbProvider"
        Me.cmbProvider.Size = New System.Drawing.Size(298, 26)
        Me.cmbProvider.TabIndex = 25
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(338, 254)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(184, 18)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Phone Number of Recipient:"
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(339, 275)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(299, 26)
        Me.txtPhone.TabIndex = 23
        '
        'Label3
        '
        Me.Label3.ForeColor = System.Drawing.Color.Gray
        Me.Label3.Location = New System.Drawing.Point(9, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(532, 45)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "This information is only necessary if you plan to use SMS in your conversations."
        '
        'txtServerIP
        '
        Me.txtServerIP.Location = New System.Drawing.Point(339, 92)
        Me.txtServerIP.Name = "txtServerIP"
        Me.txtServerIP.Size = New System.Drawing.Size(299, 26)
        Me.txtServerIP.TabIndex = 21
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(337, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 18)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "IP Address of Server:"
        '
        'cmdStartConversation
        '
        Me.cmdStartConversation.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.cmdStartConversation.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.cmdStartConversation.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdStartConversation.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.cmdStartConversation.Location = New System.Drawing.Point(0, 391)
        Me.cmdStartConversation.Name = "cmdStartConversation"
        Me.cmdStartConversation.Size = New System.Drawing.Size(659, 35)
        Me.cmdStartConversation.TabIndex = 28
        Me.cmdStartConversation.Text = "Start Conversation"
        Me.cmdStartConversation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtRecipientIP
        '
        Me.txtRecipientIP.Location = New System.Drawing.Point(10, 158)
        Me.txtRecipientIP.Name = "txtRecipientIP"
        Me.txtRecipientIP.Size = New System.Drawing.Size(299, 26)
        Me.txtRecipientIP.TabIndex = 32
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 71)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(112, 18)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Select Recipient:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(155, 18)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "IP Address of Recipient:"
        '
        'cmbRecipientName
        '
        Me.cmbRecipientName.FormattingEnabled = True
        Me.cmbRecipientName.Location = New System.Drawing.Point(10, 92)
        Me.cmbRecipientName.Name = "cmbRecipientName"
        Me.cmbRecipientName.Size = New System.Drawing.Size(299, 26)
        Me.cmbRecipientName.TabIndex = 29
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(336, 136)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(192, 18)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "Select Port Number of Server:"
        '
        'nudServerPort
        '
        Me.nudServerPort.Location = New System.Drawing.Point(339, 159)
        Me.nudServerPort.Name = "nudServerPort"
        Me.nudServerPort.Size = New System.Drawing.Size(123, 26)
        Me.nudServerPort.TabIndex = 34
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(9, 315)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 18)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "Type of email:"
        '
        'cmbEmailType
        '
        Me.cmbEmailType.FormattingEnabled = True
        Me.cmbEmailType.Location = New System.Drawing.Point(10, 336)
        Me.cmbEmailType.Name = "cmbEmailType"
        Me.cmbEmailType.Size = New System.Drawing.Size(298, 26)
        Me.cmbEmailType.TabIndex = 37
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(9, 254)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(128, 18)
        Me.Label9.TabIndex = 36
        Me.Label9.Text = "Your email address:"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(10, 275)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(299, 26)
        Me.txtEmail.TabIndex = 35
        '
        'frmLauncher
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(659, 426)
        Me.Controls.Add(Me.cmdStartConversation)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cmbEmailType)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.nudServerPort)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtRecipientIP)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cmbRecipientName)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cmbProvider)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtPhone)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtServerIP)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.chkAdvanced)
        Me.Controls.Add(Me.pnlTitleBar)
        Me.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Gainsboro
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmLauncher"
        Me.Text = "frmLauncher"
        Me.pnlTitleBar.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudServerPort, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chkAdvanced As CheckBox
    Friend WithEvents pnlTitleBar As Panel
    Friend WithEvents cmdMinimize As Label
    Friend WithEvents cmdExit As Label
    Friend WithEvents lblTitleBar As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents cmbProvider As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtServerIP As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents cmdStartConversation As Label
    Friend WithEvents txtRecipientIP As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents cmbRecipientName As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents nudServerPort As NumericUpDown
    Friend WithEvents Label8 As Label
    Friend WithEvents cmbEmailType As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtEmail As TextBox
End Class
