﻿
Imports System.Threading
Imports System.Net.Sockets
Imports System.Net
Imports System.IO
Imports System.DirectoryServices
Imports System.Text


Public Class FrmServer
    Inherits Form

    Friend WithEvents txtInput As TextBox
    Friend WithEvents txtDisplay As TextBox
    Friend WithEvents lblPort As System.Windows.Forms.Label
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents numPort As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblHostIPAddr As System.Windows.Forms.Label
    Friend WithEvents btnStop As Button

    Private connection As Socket
    Private readThread As Thread

    Private socketStream As NetworkStream

    Private writer As BinaryWriter
    Private reader As BinaryReader

    Dim portNumber As Integer
    Dim hostName As String
    Friend WithEvents lstIP4 As ListBox
    Friend WithEvents lblSelectIP As Label
    Friend WithEvents lblVersion As Label
    Friend WithEvents lstIPConnected As ListBox
    Friend WithEvents lblHostName As Label
    Dim hostIpAddr As String
    Dim clients As New Hashtable
    Dim clientSocket As TcpClient


    Public Sub New()
        MyBase.New()

        InitializeComponent()

        hostIpAddr = LocalIP()
        readThread = New Thread(AddressOf RunServer)
        'txtDisplay.ReadOnly = True
    End Sub

    Public Function LocalIP() As String
        ' Obtain the first address of local machine with addressing scheme
        For Each IP As IPAddress In Dns.GetHostEntry(Dns.GetHostName()).AddressList
            If IP.AddressFamily.ToString() = "InterNetwork" Then
                Return (IP.ToString())
            End If
        Next IP
        Return (vbNullString)
    End Function

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        portNumber = numPort.Value
        readThread.Start()
        lblHostIPAddr.Text &= lstIP4.SelectedItem
        lstIP4.Enabled = False
        numPort.Enabled = False
        btnStart.Enabled = False
        btnStop.Enabled = True
        btnStart.Visible = False
        btnStop.Visible = True
    End Sub

    Private Sub frmServer_Closing(
                                   ByVal sender As System.Object,
                                   ByVal e As System.ComponentModel.CancelEventArgs) _
                                    Handles MyBase.Closing

        System.Environment.Exit(System.Environment.ExitCode)
    End Sub

    Private Sub txtInput_KeyDown(ByVal sender As System.Object,
                                  ByVal e As System.Windows.Forms.KeyEventArgs) _
                                    Handles txtInput.KeyDown

        Try

            If (e.KeyCode = Keys.Enter AndAlso
            Not connection Is Nothing) Then

                writer.Write("SERVER>>> " & txtInput.Text)
                txtDisplay.Text &= vbCrLf & "SERVER>>> " &
                    txtInput.Text

                If txtInput.Text = "TERMINATE" Then
                    connection.Close()
                End If
                txtInput.Clear()
            End If

        Catch ex As SocketException
            txtDisplay.Text &= vbCrLf & "Error writing object"
        End Try
    End Sub

    ' Gets all the IPv4 Addresses of the computer
    Private Function GetIPv4Address() As String
        GetIPv4Address = String.Empty
        Dim strHostName As String = System.Net.Dns.GetHostName()
        Dim iphe As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(strHostName)

        For Each ipheal As System.Net.IPAddress In iphe.AddressList
            If ipheal.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then
                GetIPv4Address = ipheal.ToString()
            End If
            lstIP4.Items.Add(GetIPv4Address)
        Next
        lblHostName.Text += strHostName
    End Function

    Public Sub RunServer()

        Dim listener As TcpListener
        Dim counter As Integer = 1

        CheckForIllegalCrossThreadCalls = False
        Try

            Dim localAddr As IPAddress = IPAddress.Parse(lstIP4.SelectedItem)
            listener = New TcpListener(IPAddress.Any, portNumber)

            listener.Start()

            While True
                CheckForIllegalCrossThreadCalls = False
                txtDisplay.Text = "Waiting for connection" & vbCrLf
                'connection = listener.AcceptSocket()
                clientSocket = listener.AcceptTcpClient()
                clientSocket.GetStream()
                socketStream = clientSocket.GetStream()
                writer = New BinaryWriter(socketStream)
                reader = New BinaryReader(socketStream)

                txtDisplay.Text &= "Connection " & counter &
                    " received." & vbCrLf

                writer.Write("SERVER>>> Connection Successful")

                txtInput.ReadOnly = False
                Dim theReply As String = ""

                Try
                    Do
                        theReply = reader.ReadString()
                        txtDisplay.Text &= vbCrLf & theReply
                    Loop While (theReply <> "Client>>> TERMINATE" _
                        AndAlso clientSocket.Connected)
                Catch inputOutputExecption As IOException
                    MessageBox.Show("Client application closing")
                Finally

                    txtDisplay.Text &= vbCrLf & "User terminated connection."
                    txtInput.ReadOnly = True
                    writer.Close()
                    reader.Close()
                    socketStream.Close()
                    clientSocket.Close()
                    counter += 1
                End Try
            End While

        Catch inputOutputException As IOException
            MessageBox.Show("Server Application Closing")
        End Try
    End Sub

    Private Sub InitializeComponent()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.lblPort = New System.Windows.Forms.Label()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.numPort = New System.Windows.Forms.NumericUpDown()
        Me.lblHostIPAddr = New System.Windows.Forms.Label()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.lstIP4 = New System.Windows.Forms.ListBox()
        Me.lblSelectIP = New System.Windows.Forms.Label()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.lstIPConnected = New System.Windows.Forms.ListBox()
        Me.lblHostName = New System.Windows.Forms.Label()
        CType(Me.numPort, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(12, 108)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(258, 20)
        Me.txtInput.TabIndex = 0
        '
        'txtDisplay
        '
        Me.txtDisplay.Location = New System.Drawing.Point(12, 134)
        Me.txtDisplay.Multiline = True
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(258, 342)
        Me.txtDisplay.TabIndex = 1
        '
        'lblPort
        '
        Me.lblPort.AutoSize = True
        Me.lblPort.Location = New System.Drawing.Point(381, 15)
        Me.lblPort.Name = "lblPort"
        Me.lblPort.Size = New System.Drawing.Size(29, 13)
        Me.lblPort.TabIndex = 3
        Me.lblPort.Text = "Port:"
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(384, 39)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(86, 23)
        Me.btnStart.TabIndex = 4
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'numPort
        '
        Me.numPort.Location = New System.Drawing.Point(413, 13)
        Me.numPort.Maximum = New Decimal(New Integer() {6000, 0, 0, 0})
        Me.numPort.Minimum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.numPort.Name = "numPort"
        Me.numPort.Size = New System.Drawing.Size(57, 20)
        Me.numPort.TabIndex = 5
        Me.numPort.Value = New Decimal(New Integer() {2000, 0, 0, 0})
        '
        'lblHostIPAddr
        '
        Me.lblHostIPAddr.AutoSize = True
        Me.lblHostIPAddr.Location = New System.Drawing.Point(9, 15)
        Me.lblHostIPAddr.Name = "lblHostIPAddr"
        Me.lblHostIPAddr.Size = New System.Drawing.Size(99, 13)
        Me.lblHostIPAddr.TabIndex = 6
        Me.lblHostIPAddr.Text = "Your IP Address is: "
        '
        'btnStop
        '
        Me.btnStop.Enabled = False
        Me.btnStop.Location = New System.Drawing.Point(384, 39)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(86, 23)
        Me.btnStop.TabIndex = 7
        Me.btnStop.Text = "Stop"
        Me.btnStop.UseVisualStyleBackColor = True
        Me.btnStop.Visible = False
        '
        'lstIP4
        '
        Me.lstIP4.FormattingEnabled = True
        Me.lstIP4.Location = New System.Drawing.Point(94, 49)
        Me.lstIP4.Name = "lstIP4"
        Me.lstIP4.Size = New System.Drawing.Size(120, 30)
        Me.lstIP4.TabIndex = 8
        '
        'lblSelectIP
        '
        Me.lblSelectIP.AutoSize = True
        Me.lblSelectIP.Location = New System.Drawing.Point(12, 49)
        Me.lblSelectIP.Name = "lblSelectIP"
        Me.lblSelectIP.Size = New System.Drawing.Size(76, 13)
        Me.lblSelectIP.TabIndex = 9
        Me.lblSelectIP.Text = "Select your IP:"
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = True
        Me.lblVersion.Location = New System.Drawing.Point(357, 66)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(113, 13)
        Me.lblVersion.TabIndex = 10
        Me.lblVersion.Text = "Version: April 20, 2017"
        '
        'lstIPConnected
        '
        Me.lstIPConnected.FormattingEnabled = True
        Me.lstIPConnected.Location = New System.Drawing.Point(290, 108)
        Me.lstIPConnected.Name = "lstIPConnected"
        Me.lstIPConnected.Size = New System.Drawing.Size(178, 368)
        Me.lstIPConnected.TabIndex = 11
        '
        'lblHostName
        '
        Me.lblHostName.AutoSize = True
        Me.lblHostName.Location = New System.Drawing.Point(218, 14)
        Me.lblHostName.Name = "lblHostName"
        Me.lblHostName.Size = New System.Drawing.Size(66, 13)
        Me.lblHostName.TabIndex = 12
        Me.lblHostName.Text = "Host Name: "
        '
        'FrmServer
        '
        Me.ClientSize = New System.Drawing.Size(480, 488)
        Me.Controls.Add(Me.lblHostName)
        Me.Controls.Add(Me.lstIPConnected)
        Me.Controls.Add(Me.lblVersion)
        Me.Controls.Add(Me.lblSelectIP)
        Me.Controls.Add(Me.lstIP4)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.lblHostIPAddr)
        Me.Controls.Add(Me.numPort)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.lblPort)
        Me.Controls.Add(Me.txtDisplay)
        Me.Controls.Add(Me.txtInput)
        Me.Name = "FrmServer"
        Me.Text = "Server"
        CType(Me.numPort, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private Sub FrmServer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetIPv4Address()
    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        btnStart.Visible = True
        btnStop.Visible = False
        lstIP4.Enabled = True
        btnStart.Enabled = True
        Application.Exit()
    End Sub
End Class