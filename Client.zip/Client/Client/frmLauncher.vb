﻿Public Class frmLauncher
#Region " Move Form "
    Public MoveForm As Boolean
    Public MoveForm_MousePosition As Point

    Public Sub MoveForm_MouseDown(sender As Object, e As MouseEventArgs) Handles _
    pnlTitleBar.MouseDown, lblTitleBar.MouseDown

        If e.Button = MouseButtons.Left Then
            MoveForm = True
            MoveForm_MousePosition = e.Location
        End If

    End Sub

    Public Sub MoveForm_MouseMove(sender As Object, e As MouseEventArgs) Handles _
    pnlTitleBar.MouseMove, lblTitleBar.MouseMove

        If MoveForm Then
            Me.Location = Me.Location + (e.Location - MoveForm_MousePosition)
        End If

    End Sub

    Public Sub MoveForm_MouseUp(sender As Object, e As MouseEventArgs) Handles _
    pnlTitleBar.MouseUp, lblTitleBar.MouseUp

        If e.Button = MouseButtons.Left Then
            MoveForm = False
        End If

    End Sub
#End Region

    Private Sub frmLauncher_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Initialize with basic options
        Me.Size = New Size(319, 172)
    End Sub

    Private Sub chkAdvanced_CheckedChanged(sender As Object, e As EventArgs) Handles chkAdvanced.CheckedChanged
        'Changes size of form to show all controls if advanced is checked
        If chkAdvanced.Checked = True Then
            Me.Size = New Size(649, 418)
        ElseIf chkAdvanced.Checked = False Then
            Me.Size = New Size(319, 172)
        End If
    End Sub

    Private Sub cmdStartConversation_Click(sender As Object, e As EventArgs) Handles cmdStartConversation.Click
        If chkAdvanced.Checked = True Then
            'Pass info about recipient, server (if changed), whether or not SMS stuff was set up, etc.
            frmAdvancedClient.Show()
        ElseIf chkAdvanced.Checked = False Then
            'Pass information about recipient when implemented
            frmBasic.Show()
        End If
    End Sub

#Region " Button - Exit "
    'Conversation will be lost
    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Me.Close()
    End Sub

    'Change Backcolors on Hover
    Private Sub cmdExit_MouseEnter(sender As Object, e As EventArgs) Handles cmdExit.MouseEnter
        cmdExit.BackColor = Color.FromArgb(70, 70, 70)
    End Sub

    Private Sub cmdExit_MouseLeave(sender As Object, e As EventArgs) Handles cmdExit.MouseLeave
        cmdExit.BackColor = Color.FromKnownColor(KnownColor.Transparent)
    End Sub
#End Region
#Region " Button - Minimize "
    'Conversations won't be lost
    Private Sub cmdMinimize_Click(sender As Object, e As EventArgs) Handles cmdMinimize.Click
        Me.Hide()
    End Sub

    'Change Backcolors on Hover
    Private Sub cmdMinimize_MouseEnter(sender As Object, e As EventArgs) Handles cmdMinimize.MouseEnter
        cmdMinimize.BackColor = Color.FromArgb(70, 70, 70)
    End Sub

    Private Sub cmdMinimize_MouseLeave(sender As Object, e As EventArgs) Handles cmdMinimize.MouseLeave
        cmdMinimize.BackColor = Color.FromKnownColor(KnownColor.Transparent)
    End Sub
#End Region
End Class