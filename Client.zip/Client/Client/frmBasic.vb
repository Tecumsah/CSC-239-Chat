﻿Imports System.Threading
Imports System.Net.Sockets
Imports System.IO

'Database will hold a list of mac addresses of computers and names of the people who the computer belongs to
'arp -a command should run at the start of the app to get the available computers online.
'Program should compare the mac addresses of the computers listed when the arp command was run
'and the computers in the database. It should get the current IP address of each online computer
'that is in the list and list them by name of person who it belongs to or the name of the comp
'Example: Billy Bob or Lab Computer 3A

'In basic mode, these are the only computers you can connect to
'In advanced mode, you can enter your own IP Addresses.

Public Class frmBasic
    Private output As NetworkStream
    Private writer As BinaryWriter
    Private reader As BinaryReader
    Private message As String = ""
    Private readThread As Thread

    'Change these to the information on the server
    Private serverIP As String = "10.19.5.148"
    Private portNumber As Int32 = 2000
    'This will read in from database
    Private recipientName As String = "Carrie Broome"

    'Text to Speech
    Dim SAPI = CreateObject("SAPI.spvoice")

    Public Sub New()
        MyBase.New()

        InitializeComponent()

        readThread = New Thread(AddressOf RunClient)
        readThread.Start()
    End Sub

    Private Sub MainDocked_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'This gets the screen size of the current screen (since they aren't all the same) known as working area
        Dim workingRectangle As System.Drawing.Rectangle = Screen.PrimaryScreen.WorkingArea

        'These are the coordinates for the bottom right point on the screen.
        Dim screenX As Integer = workingRectangle.Width
        Dim screenY As Integer = workingRectangle.Height

        'Sets the location of the form (Must subtract size of form since it would be completely off screen)
        Me.Location = New Point(screenX - Me.Size.Width, screenY - Me.Size.Height)

        'Change title bar to show current recipient's name
        lblRecipient.Text = recipientName

        'Bar that displays next to chat client that shows open conversation
        'Should have control to start new conversation
        frmMenuStrip.Show()
    End Sub

    Public Sub RunClient()
        Dim client As TcpClient

        Try
            txtDisplay.Text &= "Attempting connection" & vbCrLf

            client = New TcpClient()
            client.Connect(serverIP, portNumber)

            output = client.GetStream()

            writer = New BinaryWriter(output)
            reader = New BinaryReader(output)

            txtDisplay.Text &= vbCrLf & "Got I/O streams" & vbCrLf

            txtInput.ReadOnly = False

            Try
                Do
                    message = reader.ReadString
                    txtDisplay.Text &= vbCrLf & message

                Loop While message <> "SERVER>>> TERMINATE"

            Catch inputOutputException As IOException
                MessageBox.Show("Client application closing")

            Finally
                'Close All Connections
                txtDisplay.Text &= vbCrLf & "Closing connection." & vbCrLf

                writer.Close()
                reader.Close()
                output.Close()
                client.Close()
            End Try

            Application.Exit()

        Catch ex As Exception
            MessageBox.Show("Client application closing")
        End Try
    End Sub

    Public Sub SendMessage()
        Try
            writer.Write("CLIENT>>> " & txtInput.Text)

            txtDisplay.Text &= vbCrLf & "CLIENT>>> " & txtInput.Text

            'Speak outgoing messages if checked.
            If chkSpeech.Checked = True Then
                SAPI.Speak(txtInput.Text)
            End If

            txtInput.Clear()
        Catch execption As SocketException
            txtDisplay.Text &= vbCrLf & "Error writing object"
        End Try
    End Sub


#Region " Enter to Send "
    Private Sub txtInput_KeyDown(sender As Object, e As KeyEventArgs) Handles txtInput.KeyDown
        'If The user has checked the "Press Enter to send" check box
        If chkEnter.Checked = True And e.KeyCode = Keys.Enter Then
            SendMessage()
        End If
    End Sub
#End Region
#Region " Button - Send "
    Private Sub cmdSend_Click(sender As Object, e As EventArgs) Handles cmdSend.Click
        SendMessage()
    End Sub

    'Change color on hover
    Private Sub cmdSend_MouseEnter(sender As Object, e As EventArgs) Handles cmdSend.MouseEnter
        cmdSend.BackColor = Color.FromArgb(70, 70, 70)
    End Sub

    Private Sub cmdSend_MouseLeave(sender As Object, e As EventArgs) Handles cmdSend.MouseLeave
        cmdSend.BackColor = Color.FromArgb(64, 64, 64)
    End Sub
#End Region

#Region " Button - Exit "
    'Conversation will be lost
    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Me.Close()
    End Sub

    'Change Backcolors on Hover
    Private Sub cmdExit_MouseEnter(sender As Object, e As EventArgs) Handles cmdExit.MouseEnter
        cmdExit.BackColor = Color.FromArgb(70, 70, 70)
    End Sub

    Private Sub cmdExit_MouseLeave(sender As Object, e As EventArgs) Handles cmdExit.MouseLeave
        cmdExit.BackColor = Color.FromKnownColor(KnownColor.Transparent)
    End Sub
#End Region
#Region " Button - Minimize "
    'Conversations won't be lost
    Private Sub cmdMinimize_Click(sender As Object, e As EventArgs) Handles cmdMinimize.Click
        Me.Hide()
    End Sub

    'Change Backcolors on Hover
    Private Sub cmdMinimize_MouseEnter(sender As Object, e As EventArgs) Handles cmdMinimize.MouseEnter
        cmdMinimize.BackColor = Color.FromArgb(70, 70, 70)
    End Sub

    Private Sub cmdMinimize_MouseLeave(sender As Object, e As EventArgs) Handles cmdMinimize.MouseLeave
        cmdMinimize.BackColor = Color.FromKnownColor(KnownColor.Transparent)
    End Sub
#End Region


End Class