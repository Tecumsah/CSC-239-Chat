﻿Public Class frmNewConversation
#Region " Button - Exit "
    'Conversation will be lost
    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Me.Close()
    End Sub

    'Change Backcolors on Hover
    Private Sub cmdExit_MouseEnter(sender As Object, e As EventArgs) Handles cmdExit.MouseEnter
        cmdExit.BackColor = Color.FromArgb(70, 70, 70)
    End Sub

    Private Sub cmdExit_MouseLeave(sender As Object, e As EventArgs) Handles cmdExit.MouseLeave
        cmdExit.BackColor = Color.FromKnownColor(KnownColor.Transparent)
    End Sub
#End Region
#Region " Button - Minimize "
    'Conversations won't be lost
    Private Sub cmdMinimize_Click(sender As Object, e As EventArgs) Handles cmdMinimize.Click
        Me.Hide()
    End Sub

    'Change Backcolors on Hover
    Private Sub cmdMinimize_MouseEnter(sender As Object, e As EventArgs) Handles cmdMinimize.MouseEnter
        cmdMinimize.BackColor = Color.FromArgb(70, 70, 70)
    End Sub

    Private Sub cmdMinimize_MouseLeave(sender As Object, e As EventArgs) Handles cmdMinimize.MouseLeave
        cmdMinimize.BackColor = Color.FromKnownColor(KnownColor.Transparent)
    End Sub
#End Region
End Class