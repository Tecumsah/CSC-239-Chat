﻿Public Class frmMenuStrip
    Private Sub frmMenuStrip_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'This gets the screen size of the current screen (since they aren't all the same) known as working area
        Dim workingRectangle As System.Drawing.Rectangle = Screen.PrimaryScreen.WorkingArea

        'These are the coordinates for the bottom right point on the screen.
        Dim screenX As Integer = workingRectangle.Width
        Dim screenY As Integer = workingRectangle.Height

        'Sets the location of the form (Must subtract size of form since it would be completely off screen)
        Me.Location = New Point(screenX - Me.Size.Width - frmBasic.Size.Width, screenY - Me.Size.Height)
    End Sub
End Class